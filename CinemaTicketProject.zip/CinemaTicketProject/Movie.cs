﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketProject
{
    internal class Movie:Inheritance
    {
        public string MovieName { get; set; }
        public string MovieTime { get; set; }
        public string TheaterName { get; set; } 
        public double TicketPrice { get; set; }

    }
}
