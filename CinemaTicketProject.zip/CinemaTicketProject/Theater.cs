﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaTicketProject
{
    internal class Theater:Inheritance
    {
      
        public int MovieId { get; set; }
        public int SeatQuantity { get; set; }  

    }
}
